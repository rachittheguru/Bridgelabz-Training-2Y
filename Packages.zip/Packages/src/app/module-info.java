module app {
    requires collegeinfo;
}
